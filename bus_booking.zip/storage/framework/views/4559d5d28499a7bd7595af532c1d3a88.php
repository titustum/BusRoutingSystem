


<img src="<?php echo e(asset('images/logo.png')); ?>" alt="Bus Logo" <?php echo e($attributes); ?>>
<?php /**PATH F:\Projects\Laravel\BusRoutingSystem\resources\views/components/application-logo.blade.php ENDPATH**/ ?>