<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['header' => 'Driver']); ?>


    <div class="flex flex-col w-full h-screen p-4 my-16">

             <div class="text-orange-600 pb-3 flex items-center justify-between border-b-2 border-orange-600 text-xl text-center uppercase font-['Righteous']">
                <a href="<?php echo e(route('dashboard')); ?>" class="text-sm text-gray-600"><i class="mr-1 fas fa-arrow-left"></i>Back</a>
                <?php echo e($journeys->count()); ?> | AVAILABLE JOURNEYS
                <div></div>
             </div>

             

             <div class="my-5 ">
                 <h1 class="py-3 border-b border-orange-600">Your recently added travels</h1>

                 <div class="grid gap-3 mt-4">

                    <?php $__currentLoopData = $journeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $journey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="grid grid-cols-3 gap-3 p-3 border rounded-md shadow">
                        <div>
                            <div class="flex flex-col text-center justify-center h-[90%] w-full bg-gray-200 rounded-md">
                                <i class="text-orange-600 fas fa-bus"></i>
                                <?php if($journey->driver): ?>
                                    <h1 class="font-bold"><?php echo e($journey->driver->company_name); ?></h1>
                                    <h1 class="text-sm"><?php echo e($journey->driver->vehicle_number); ?></h1>
                                <?php else: ?>
                                    <h1 class="font-bold">Bus Kenya</h1>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-span-2 text-sm">
                            <div>Route: <b><?php echo e($journey->origin); ?> to <?php echo e($journey->destination); ?></b></div>
                            <div>Start Time: <?php echo e($journey->departure_time); ?></div>
                            <div>Ticket Price: <b>KSh. <?php echo e(number_format($journey->price)); ?></b></div>
                            <a href="<?php echo e(route('journeys.show', $journey)); ?>" class="text-blue-600">
                                More Details <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                 </div>

     </div>



  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH F:\Projects\Laravel\BusRoutingSystem\resources\views/journey/search.blade.php ENDPATH**/ ?>