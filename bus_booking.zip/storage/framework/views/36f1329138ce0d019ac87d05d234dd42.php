<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="h-screen w-full  flex flex-col p-4">
        <div class="mt-6 flex-grow">
            <h1 class="text-orange-600 uppercase text-2xl text-center font-bold font-['Righteous']">School Bus Booking</h1>

            <p class="mt-5 text-zinc-900 w-[90%] mx-auto">
                This is a bus trackig  routing system that lets passengers
                especially students to book tickets and
                pay for the seats prior to the time of travel.
            </p>

            <img src="<?php echo e(asset('images/school bus routing.webp')); ?>" alt="School Bus" class="mt-6">

        </div>
        <div class="shrink-0 grid gap-2 mb-4 w-[90%] mx-auto">

            <?php if(auth()->guard()->check()): ?>

            <a href="<?php echo e(route('dashboard')); ?>" class="block text-center py-3 px-6 bg-orange-600 rounded-md text-white hover:opacity-80">
                Go To Dashboard
            </a>

            <?php else: ?>
             <a href="<?php echo e(route('login')); ?>" class="block text-center py-3 px-6 bg-black rounded-md text-white hover:opacity-80">
                Login
            </a>
            <a href="<?php echo e(route('register')); ?>" class="block text-center py-3 px-6 bg-orange-600 rounded-md text-white hover:opacity-80">
                Create Account
            </a>
            <?php endif; ?>


        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH F:\Projects\Laravel\BusRoutingSystem\resources\views/welcome.blade.php ENDPATH**/ ?>