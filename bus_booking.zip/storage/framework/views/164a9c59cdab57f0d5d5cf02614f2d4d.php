<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['header' => 'Passenger']); ?>


    <div class="flex flex-col w-full min-h-[70vh] p-4 my-16">

            <div>
                <a href="<?php echo e(route('dashboard')); ?>" class="px-4 py-2 text-sm text-black bg-gray-100 rounded-md"><i class="mr-2 fas fa-arrow-left"></i>Back</a>
            </div>
             <div class="text-orange-600 text-xl mt-4 text-center uppercase font-['Righteous']">
                <?php echo e($journey->origin); ?> <i class="text-green-600 fas fa-arrow-right"></i>  <?php echo e($journey->destination); ?> JOURNEY

             </div>

             

             <div class="my-5">
                 <h1 class="flex justify-between py-3 border-b border-orange-600">
                    Journey details

                    <span class="text-sm">
                        <i class="far fa-clock"></i>:
                        <?php echo e($journey->created_at); ?>

                    </span>
                 </h1>

                 <div id="details" class="my-2">
                    <div class="detail-item">
                        <strong>Start Location:</strong>
                        <span id="start-location"><?php echo e($journey->origin); ?></span>
                    </div>
                    <div class="detail-item">
                        <strong>End Location:</strong>
                        <span id="end-location"><?php echo e($journey->destination); ?></span>
                    </div>
                    <div class="detail-item">
                        <strong>Driver Name:</strong>
                        <span id="distance"><?php echo e($journey->user->name); ?></span>
                    </div>
                    <div class="detail-item">
                        <strong>Bus Type:</strong>
                        <span id="distance"><?php echo e($journey->driver->vehicle_type); ?></span>
                    </div>
                    <div class="detail-item">
                        <strong>Bus Number:</strong>
                        <span id="distance"><?php echo e($journey->driver->vehicle_number); ?></span>
                    </div>
                    <div class="detail-item">
                        <strong>Estimated Price:</strong>
                        <span id="distance">Ksh. <?php echo e(number_format($journey->price)); ?></span>
                    </div>
                    

                    <div id="info"></div>

                    <div class="detail-item">
                        <strong>Distance:</strong>
                        <span id="distance"><?php echo e($journey->distance); ?> KM</span>
                    </div>
                    <div class="detail-item">
                        <strong>Estimated Time:</strong>
                        <span id="estimated-time"><?php echo e($duration); ?></span>
                    </div>
                </div>

                <img id="map" class="min-h-[300px] rounded-md w-auto" src="<?php echo e($mapUrl); ?>" alt="Journey Map">

             </div>



             <div class="flex justify-between mt-auto">
                <a href="<?php echo e(route('dashboard')); ?>" class="px-6 py-3 bg-gray-400 rounded-md">Back</a>
                <a href="<?php echo e(route('journey.pay', $journey->id)); ?>" class="block px-6 py-3 text-white bg-orange-600 rounded-md">Book @ KSh. <?php echo e(number_format($journey->price)); ?> </a>
             </div>

     </div>



  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH F:\Projects\Laravel\BusRoutingSystem\resources\views/journey/show.blade.php ENDPATH**/ ?>