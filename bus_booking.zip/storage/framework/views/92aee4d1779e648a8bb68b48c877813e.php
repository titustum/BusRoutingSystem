<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['header' => 'Driver']); ?>


    <div class="flex flex-col w-full h-screen p-4 my-16">

        <div class="text-orange-600 pb-3 flex items-center justify-between border-b-2 border-orange-600 text-xl text-center uppercase font-['Righteous']">
            <a href="<?php echo e(route('dashboard')); ?>" class="text-sm text-black"><i class="mr-1 fas fa-arrow-left"></i>Back</a>
            <?php echo e(Auth::user()->journeys->count() ?? 0); ?> | DRIVER JOURNEYS
            <div></div>
         </div>

        

        <div class="my-5 ">
            <h1 class="py-3 border-b border-orange-600">Your recently added travels</h1>

            <div class="grid gap-3 mt-4">

                <?php if(empty(Auth::user()->journeys)): ?>

                You have no journeys

                <?php else: ?>
                    <?php $__currentLoopData = Auth::user()->journeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $journey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="grid grid-cols-3 gap-3 p-3 border rounded-md shadow">
                            <div>
                                <div class="flex flex-col justify-center w-full h-full text-center bg-gray-200 rounded-md">
                                    <h1 class="text-2xl font-bold text-green-600"><?php echo e($journey->payments()->count()); ?></h1>
                                    <div>Booked</div>

                                </div>
                            </div>
                            <div class="col-span-2 text-sm">
                                <div>Route: <?php echo e($journey->origin); ?> to <?php echo e($journey->destination); ?></div>
                                <div>
                                    Departure: <?php echo e(\Carbon\Carbon::parse($journey->departure_date)->format('d-m-Y')); ?>

                                    <?php echo e(\Carbon\Carbon::parse($journey->departure_time)->format('H:s a')); ?>

                                </div>
                                <div>Ticket Price: <b>KSh. <?php echo e(number_format($journey->price)); ?></b> </div>
                                <a href="<?php echo e(route('driver.show.booking', $journey->id)); ?>" type="submit"
                                    class="w-full mx-auto text-center text-blue-600">
                                    View bookings
                                </a>
                            </div>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endif; ?>



            </div>

        </div>



  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH F:\Projects\Laravel\BusRoutingSystem\resources\views/journey/index.blade.php ENDPATH**/ ?>