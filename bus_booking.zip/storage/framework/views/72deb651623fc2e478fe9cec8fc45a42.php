<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['header' => 'Admin']); ?>


    <div class="flex flex-col w-full h-screen p-4 my-16">

             <div class="text-orange-600 pb-3 flex items-center justify-between border-b-2 border-orange-600 text-xl text-center uppercase font-['Righteous']">

                <a href="<?php echo e(route('dashboard')); ?>" class="text-sm text-black"><i class="mr-1 fas fa-arrow-left"></i>Back</a>

                ADMIN | VIEW DRIVERS

                <div></div>
             </div>


             <div class="max-w-full mt-4 overflow-x-auto">
                <table class="w-full overflow-hidden bg-white rounded-lg shadow-md">
                  <thead class="bg-orange-200">
                    <tr>
                      <th class="px-4 py-3 text-xs font-medium tracking-wider text-left text-gray-600 uppercase">ID</th>
                      <th class="px-4 py-3 text-xs font-medium tracking-wider text-left text-gray-600 uppercase">Name</th>
                      <th class="px-4 py-3 text-xs font-medium tracking-wider text-left text-gray-600 uppercase">Email</th>
                      <th class="px-4 py-3 text-xs font-medium tracking-wider text-left text-gray-600 uppercase">Role</th>
                    </tr>
                  </thead>
                  <tbody class="divide-y divide-gray-200">
                    <tbody class="divide-y divide-gray-200">
                        <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr class="hover:bg-gray-50">
                            <td class="px-4 py-4 whitespace-nowrap"><?php echo e($user->id); ?></td>
                            <td class="px-4 py-4 whitespace-nowrap"><?php echo e($user->name); ?></td>
                            <td class="px-4 py-4 whitespace-nowrap"><?php echo e($user->email); ?></td>
                            <td class="px-4 py-4 whitespace-nowrap"><?php echo e($user->role); ?></td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </tbody>
                </table>
              </div>



     </div>

  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH F:\Projects\Laravel\BusRoutingSystem\resources\views/admin/view_drivers.blade.php ENDPATH**/ ?>