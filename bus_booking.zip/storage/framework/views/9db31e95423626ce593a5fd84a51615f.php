<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['header' => 'Driver']); ?>


   <div class="flex flex-col w-full h-screen p-4 my-16">

            <div class="text-orange-600 pb-3 border-b-2 border-orange-600 text-xl text-center uppercase font-['Righteous']">
                DRIVER | DASHBOARD
            </div>


            <div class="grid grid-cols-2 gap-4 p-3 mt-3">

                <a href="<?php echo e(route('journeys.create')); ?>" class="min-h-[20vh] hover:bg-orange-200 transition-all duration-300 focus:bg-orange-200 border rounded-md shadow shadow-orange-600 flex flex-col justify-center">
                    <div class="text-center">
                        <i class="fas fa-road fa-2x"></i>
                        <div class="mt-2">New Journey</div>
                    </div>
                </a>
                <a href="<?php echo e(route('journeys.index')); ?>" class="min-h-[20vh] hover:bg-orange-200 transition-all duration-300 focus:bg-orange-200 border rounded-md shadow shadow-orange-600 flex flex-col justify-center">
                    <div class="text-center">
                        <i class="fas fa-bus fa-2xl"></i>
                        <div class="mt-2">My Journeys</div>
                    </div>
                </a>
                <a href="<?php echo e(route('driver.view.bookings')); ?>" class="min-h-[20vh] hover:bg-orange-200 transition-all duration-300 focus:bg-orange-200 border rounded-md shadow shadow-orange-600 flex flex-col justify-center">
                    <div class="text-center">
                        <i class="fas fa-check fa-2xl"></i>
                        <div class="mt-2">Bookings</div>
                    </div>
                </a>
                <a href="<?php echo e(route('profile.edit')); ?>" class="min-h-[20vh] hover:bg-orange-200 transition-all duration-300 focus:bg-orange-200 border rounded-md shadow shadow-orange-600 flex flex-col justify-center">
                    <div class="text-center">
                        <i class="fas fa-user fa-2xl"></i>
                        <div class="mt-2">My Profile</div>
                    </div>
                </a>

            </div>



    </div>








 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH F:\Projects\Laravel\BusRoutingSystem\resources\views/driver/dashboard.blade.php ENDPATH**/ ?>