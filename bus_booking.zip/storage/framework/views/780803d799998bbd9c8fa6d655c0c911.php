<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['header' => 'Passenger']); ?>
    <div class="mx-auto mt-24 w-[90%] border shadow-md rounded p-8">
        <h1 class="mb-4 text-2xl font-bold">Payment Status</h1>
        <div class="bg-white">
            <p>Payment ID: <b><?php echo e($payment->id); ?></b></p>
            <p>Amount: <b><?php echo e($payment->amount); ?></b></p>
            <p>Status: <b><?php echo e(ucfirst($payment->status)); ?></b></p>
            <?php if($payment->status == 'completed'): ?>
                <p>M-Pesa Receipt Number: <?php echo e($payment->mpesa_receipt_number); ?></p>
            <?php endif; ?>

            <div class="flex justify-between mt-6">
                <a href="<?php echo e(route('dashboard')); ?>" class="px-4 py-2 text-white bg-black rounded-lg hover:opacity-80">Back To Home</a>

                <form action="<?php echo e(route('logout')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="px-4 py-2 text-white bg-red-600 rounded-lg hover:opacity-80">Logout</button>
                </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH F:\Projects\Laravel\BusRoutingSystem\resources\views/payments/payment-status.blade.php ENDPATH**/ ?>